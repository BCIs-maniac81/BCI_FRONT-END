// BCI_LMSE_ESP.cpp -------- File.

# include "BCI_LMSE_ESP.h"
//# include "pins_arduino.h"
# include <SPI.h>
# include <stdlib.h>
# include "esp32-hal-spi.h"


	float _tCLK = 0.000666; // in milliseconds = 666ns(MAX) or 414ns(MIN) for MASTER CLOCK. 
	float _tRST;
	float _tPOR;
	float _tSTART;
	float _tREAD;
	float _tUPDATE;
	float _tSDECODE;
	
SPIClass * vspi = NULL; // create an instance vspi in SPIClass.
//**** breakout ESP32 ****//
/* DRDY = 12, RESET = 13, CS = 15, MOSI = 23, MISO = 19, SCK = 18 */

void BCI_LMSE_ESP::initialize(int _ESP_DRDY, int _ESP_CS, int _ESP_RST) {

	//*************************** DECLARATIONS ************************/

	DRDY = _ESP_DRDY;
	CS = _ESP_CS;
	
	RST = _ESP_RST;

	pinMode(DRDY, INPUT); // to receive Data Ready signal from ADS1299 Chip.
	digitalWrite(DRDY, HIGH); // Do nothing until receiving Ready data Signal
	
	pinMode(CS, OUTPUT); // Output to select the Device (ADS1299).
	digitalWrite(CS, HIGH); // Device not selected in this level.
	
	
	_tPOR = pow(2.0,18)*_tCLK; //Wait after power up until RESET, the min value is (2^18*tCLK);
	_tRST =  2.0*_tCLK; // Reset Low Duration , the min value is (2*tCLK);
	_tSTART = 18.0*_tCLK - _tRST; // Duration to wait before using the Device.
	_tSDECODE = 4.0*_tCLK; // Necessary time to decode any command (in byte)

// *************************** POWER-UP SEQUENCING ************************//
	delay(_tPOR); // necessary time to get the power-supplies stabilized, and reach their final values. 
	pinMode(RST, OUTPUT); // Configure RST pin to be an OUTPUT.
	digitalWrite(RST, LOW); // Transmit RESET pulse by command to initialize the digital portion of the ADS1299.
	delay(_tRST); // RESET Low Duration before turning to HIGH.
	digitalWrite(RST, HIGH);
	delay(_tSTART); // Recommended dalay to have all registers in their default configuration. 

// *************************** SPI settings. ***************************//
// MISO is automatically set to INPUT.
	pinMode(SCK, OUTPUT);
	pinMode(MOSI, OUTPUT);
	pinMode(MISO, INPUT);
	// pinMode(SS, OUTPUT); // pinMode(CS, OUTPUT)--> This pin is mapped with CS=15.
	
// set SPI Outputs values.
	digitalWrite(SCK, LOW);
	digitalWrite(MOSI, LOW);
	//digitalWrite(SS, HIGH); // because SS slave is active Low --> This pin is mapped with CS=15.
	

// SPI initialization
	
	vspi = new SPIClass(VSPI);
	vspi->begin();
	vspi->beginTransaction(SPISettings(spiClk, MSBFIRST, SPI_MODE1));

	/*-- RESET SRB2,BIAS_IN inclusion arrays and set channel settings to default */

	for (uint8_t i = 0; i<8; i++){
		SRB2_include[i] = false; 		// SRB2 inclusion.
		BIAS_SENS_routing[i] = false; 	// BIAS generation.
		defaultChannelSettings(i+1);
	}
	resetADS1299();          // Use the function to load the default parameters for ADS.
	
}

// ************************* using SRB1, SRB2 and BIAS_SENS ********************* //

void BCI_LMSE_ESP::SRB2SETTER(uint8_t numCH){
	SRB2_include[numCH-1] = true;
	channelSettings[numCH-1][CH_SRB2] = 1;
	CHnSET0 = RREG(CH1SET + numCH-1);
	bitSet(CHnSET0, 3);
	WREG(CH1SET + numCH-1, CHnSET0);
	CHnSET0 = 0x00;
}

void BCI_LMSE_ESP::SRB1SETTER(){
	SRB1_include = true;
	for(uint8_t numCH=1; numCH<=8; numCH++){
		channelSettings[numCH-1][CH_SRB1] = 1;
	}
	MISC1_buff = RREG(MISC1);
	bitSet(MISC1_buff, 5);
	WREG(MISC1, MISC1_buff);		
}

void BCI_LMSE_ESP::BIAS_SENS_ROUTING(uint8_t numCH){
	BIAS_SENS_routing[numCH-1] = true;
	channelSettings[numCH-1][CH_BIAS_ROUTING] = 1;
	CONFIGn = RREG(CONFIG3);
	CONFIGn |=BIAS_SENS_MASK; // enable internal refernce Buffer, internal BIASREF signal, BIAS buffer and BIAS sens.
	WREG(CONFIG3, CONFIGn);
	BIAS_P = RREG(BIAS_SENSP); 		// Read BIAS Positive Signal derivation Register 
	BIAS_N = RREG(BIAS_SENSN);   	// Read BIAS Negative Signal derivation Register.
	bitSet(BIAS_P, numCH-1);   		// enable the routing of numCH-th into positive BIAS derivation.
	WREG(BIAS_SENSP, BIAS_P);    	// Write the new value to BIAS_SENSP register.
	bitSet(BIAS_N, numCH-1);   		// enable the routing of numCH-th into negative BIAS derivation.
	WREG(BIAS_SENSN, BIAS_N);    	//Write the new value to BIAS_SENSN register.
	BIAS_P = BIAS_N = 0x00;
}
	
 
// *****************************  SYSTEM COMMANDS ********************************* //
// These Commands are: WAKEUP, STANDBY, START, STOP, RESET.
//*************** WAKEUP FUNCTION ********************** //
void BCI_LMSE_ESP::WAKEUP() {
	digitalWrite(CS, LOW); // enable the communication.
	SPI_transfer(_WAKEUP);
	digitalWrite(CS, HIGH); // end of communication.
	delay(_tSDECODE+0.008); // must wait at least (4*_tCLK) cycles before sending any other command (Datasheet, page40)
	// The WAKEUP command exits low-power standby mode
} 

//*************** STANDBY FUNCTION ********************** //
void BCI_LMSE_ESP::STANDBY() {
	digitalWrite(CS, LOW);
	SPI_transfer(_STANDBY);
	digitalWrite(CS, HIGH);
	// this is the only command to send after this mode is the:  WAKEUP.
}

//*************** RESET FUNCTION ********************** //
void BCI_LMSE_ESP::RESET(){
	digitalWrite(CS, LOW); // enable the communication
	SPI_transfer(_RESET);
	delay(_tSTART); 	  //at least (18*_tCLK -_tRST) are required to execute the RESET command in order to complete 
						 // initializaton of the configuration registers to default states(Datasheet pg. 35 and 41).
	digitalWrite(CS, HIGH);
}

//*************** START FUNCTION ********************** //
// There are no SCLK rate restrictions for this command and can be issued at any time.
void BCI_LMSE_ESP::START() { // This command is used to begin the conversion. 
	digitalWrite(CS, LOW); // enable the communication
	SPI_transfer(_START);
	delay(2.0*_tCLK); // it's quite to do this (datasheet page.34).
	digitalWrite(CS, HIGH); // end of communication.
}

//*************** STOP FUNCTION ************************ //
// There are no SCLK rate restrictions for this command and can be issued at any time.
void BCI_LMSE_ESP::STOP() { // This command is used to stop the conversion.
	digitalWrite(CS, LOW); // enable the communication
	SPI_transfer(_STOP);
	digitalWrite(CS, HIGH); // end of communication.
}

// *****************************  DATA READ COMMANDS ********************************* //
// These Commands are: RDATAC, SDATAC, RDATA.

// ********************* RDATAC FUNCTION ********************************//
// There are no SCLK rate restrictions for this command and can be issued at any time.
void BCI_LMSE_ESP::RDATAC() { // Read DATA continuous.
	digitalWrite(CS, LOW); // enable the communication
	SPI_transfer(_RDATAC);
	digitalWrite(CS, HIGH); // end of communication.
	delay(_tSDECODE+0.008); // see datasheet pg.41 for this restriction.
}

// ********************* SDATAC FUNCTION ********************************//
// There are no SCLK rate restrictions for this command and can be issued at any time.
void BCI_LMSE_ESP::SDATAC() { // Stop read DATA continuous
	digitalWrite(CS, LOW); // enable the communication
	SPI_transfer(_SDATAC);
	digitalWrite(CS, HIGH); // end of communication.
	delay(_tSDECODE +0.008); // wait at least 4*tCLK after this command -> see datasheet pg.42 for this restriction.
}
	
// ********************** RDATA FUNCTION ******************************************// 
// There are no SCLK rate restrictions for this command and can be issued at any time.
void BCI_LMSE_ESP::RDATA2(){ // This fonction is used to send _RDATA command.	
	
	SPI_transfer(_RDATA);
	delay(_tSDECODE+0.008);
} 

//********************* Reading Data on demand  RDATA MODE  *********************************/
void BCI_LMSE_ESP::RDATA() {
 		
	resetStatusRegister(); // reset the Status register content to default values =0.
	resetChannelsData();   // reset the channles DATA buffer to default values = 0.
	
	digitalWrite(CS, LOW);  // enable the communication
	SPI_transfer(_SDATAC);  // First we must stop the read DATA continuous mode.
	RDATA2();              // Send the _RDATA command.
	
	/*  1- Read Status Register => 03 Bytes(24bits) = [1100 + LOFF_STATP + LOFF_STATN + GPIO_Bits[7:4]] */
	for(uint8_t i = 0; i<3; i++) {
		status_reg[i] =  SPI_transfer(_pop_read);
		delay(0.001);
	}
		
		if(details) { // this will show the status register content.
			Serial.print("STAUS REGISTER: ");
			uint8_t li=0;
			for(uint8_t j=0; j<3; j++){
				for(uint8_t k=0; k<8; k++){
				Serial.print(bitRead(status_reg[j], 7-k), BIN);
				++li;
				if(li!=24) {
					Serial.print(", ");
				}
				}
			}
			Serial.println("");
		}
	/* 2- Read All 24Bit channels  */
		Serial.println(" CHANNELS DATA IN 24Bit 2'S COMPLEMENT ");
	for(uint8_t i=0; i<8; i++){
		for(uint8_t j=0; j<3; j++){
			bufferByte = SPI_transfer(_pop_read);
			channel[i] = (channel[i] << 8) | bufferByte;
		}

	}
	bufferByte = 0x00; // reset the buffer.

	digitalWrite(CS, HIGH);
	if(details){
		
	for(uint8_t i = 0; i<8; i++){
		uint8_t li =0 ;
		Serial.print("CH 0");
		Serial.print(i+1);
		Serial.print(" : ");
		for(uint8_t j=0; j<32; j++){
			li++;
			Serial.print(bitRead(channel[i], 31-j), BIN);
			if(li!=32) {
				Serial.print(", ");
			}
		}
		Serial.println("");
	}
	}

/* **************************** Data reformating & conversion into 32bit 2's complement ********************************* */ 
	Serial.println(" CHANNELS DATA IN 32Bit 2'S COMPLEMENT ");
	for (uint8_t i=0; i<8; i++){
		if(bitRead(channel[i], 23) == 0){
			channel[i] = channel[i] & 0x00FFFFFF;
		}else{
			channel[i] = channel[i] | 0xFF000000;
		}
	}
	if(details){
		
		for(uint8_t i = 0; i<8; i++){
			uint8_t li =0 ;
			Serial.print("CH 0");
			Serial.print(i+1);
			Serial.print(" : ");
			for(uint8_t j=0; j<32; j++){
				li++;
				Serial.print(bitRead(channel[i], 31-j), BIN);
				if(li!=32) {
					Serial.print(", ");
				}
			}
			Serial.println("");
		}
	}

}

// ************************************************************** //
void BCI_LMSE_ESP::updateChannels() {
	resetStatusRegister();
	resetChannelsData();
	digitalWrite(CS, LOW); // Start SPI communication.
	
				/**** READ CHANNEL DATA FROM ADS1299 ****/
// **** 1- pop the 24bit Status Register
	for (int i=0; i<3; i++){
		status_reg[i] = SPI_transfer(_pop_read);
		delay(0.00001);
	}
	
	for(uint8_t i=0; i<8; i++){
		for(uint8_t j=0; j<3; j++) {
			bufferByte = SPI_transfer(_pop_read);
			channel[i] = (channel[i]<<8) | bufferByte;
		}
	}
	digitalWrite(CS, HIGH); // end of communication.

	// ***************************** Data reformating ********************************* //
	for (uint8_t i=0; i<8; i++){
		if(bitRead(channel[i], 23) == 0){
			channel[i] = channel[i] & 0x00FFFFFF;
		} else {
			channel[i] = channel[i] | 0xFF000000;
		}
	}
}

void BCI_LMSE_ESP::allDataChannelsDisplay(long signal_samples){
	if(signal_samples <= 0){Serial.println("Nothing to display!");
	}else{
		Serial.print(signal_samples);
		Serial.print(", ");
	}
	uint8_t CH = 0;
	do {
		Serial.print(channel[CH]);
		if(CH!=8){
			Serial.print(", ");
		}
		CH++;

	}while(CH<8);
	Serial.println("");
}

// *************************** DATA SENDER THROUGH SERIAL PORT **************************//

void BCI_LMSE_ESP::BinaryDataSenderToSerial(uint8_t bci_dimension,long signal_samples){
	Serial.write((byte) COMMUNICATION_START);
	Serial.write((1+bci_dimension)*4); // amount (in 1-Byte) of transmitted data, expressed in Bytes.
						   // e.g if N = 8 => Amount = 9*4=36-Byte = 288-bit <=> (8CH + 1STAT * 4).
	buff_val1 = signal_samples;	// long int<=>32-bit(4-Byte)[buff_val1]=long int<=>32-bit(4-Byte)[buff_val2]. 
	Serial.write(buff_val2, 4); // Byte buff_val2 <=> (8*4)  ---> send 4-Byte = 32-bit.
	for(uint8_t CH = 1; CH<=8; CH++){
		buff_val1 = channel[CH-1];
		Serial.write(buff_val2, 4); //send 4 Bytes in 1 Shot.
	}
	Serial.write((byte) COMMUNICATION_END);
}

// ****************** other Data Binary Format *************************** //
// ************** 1: ModularEEG --> P2 protocol (program: BrainBay).
// in this case we have to send only 6-channels of data, per the P2 protocol.

void BCI_LMSE_ESP::dataSenderToSerialAsOpenEEG_brainBay(long signal_samples){
	static int count = -1;
	sync0 = 0xA5;
	sync1 = 0x5A;
	version = 0x02;

	Serial.write(sync0);
	Serial.write(sync1);
	Serial.write(version);

	foo = (byte) signal_samples;
	if(foo == sync0) foo--;
	Serial.write(foo);

	for(uint8_t CH=1; CH <=6 ;CH++){
		buff_val32 = channel[CH-1];

		// prepare value to the transmission.
	
		buff_val32 = buff_val32 / (32);
		buff_val32 = constrain(buff_val32, min_modular_EEG_int16, max_modular_EEG_int16);
		buff_val1_u16 = (unsigned int)(buff_val32 & (0x0000FFFF));
		if(buff_val1_u16 > 1023) buff_val1_u16 = 1023;

		foo = (byte)((buff_val1_u16 >> 8) & (0x00FF));
		if(foo == sync0){
			foo--;
		}
		Serial.write(foo);
		foo = (byte)(buff_val1_u16 & 0x00FF);
		if(foo == sync0) foo--;
		Serial.write(foo);
	}
	
	switches = 0x07;
	count++;
	if(count >=18){
		 count = 0;
	}
	if(count >= 9){
		switches = 0x0F;
	}

	Serial.write(switches);
}

// ********************** DATA Acquisition Streaming Functions *********************** //
// *************************    START STREAMING  ***************************** //
void BCI_LMSE_ESP::resetADS1299(){
	resetStatusRegister();
	resetChannelsData();
	RESET();
	SDATAC();
	for (uint8_t i=1; i<=8; i++){
		powerDownChannels(i);
	}
	
	daisyChainModeTest();         // Set to Daisy-chain mode or multiple readback.
	dataRateSettings(500);        // Keep data rate to default settings 250SPS.
	testSignalSources();          // if there is no external test signal keep to generate the internal one if true.
	testSignalAmplitude();   	  // This determines the calibration signal amplitude = -1*(VREFP - VREFN)/2400.
	testSignalFrequency(21);	  // This determines the calibration signal frequency =fCLK/2^21.
	pdInternalReferenceBuffer();  // power ON/DOWN the internal reference buffer.
	biasSignalReference(); 		  // external or internal BIAS source.
	biasBufferPower();     		  // Power ON bias buffer.*/
	isADSWorking = false;
} 

void BCI_LMSE_ESP::daisyChainModeTest(){
	CONFIGn = RREG(CONFIG1);
	if(daisy_chain_mode==false){
		bitSet(CONFIGn, 6);
		WREG(CONFIG1, CONFIGn);
		multiple_readback_mode = true;
	}else{
		bitClear(CONFIGn, 6);
		WREG(CONFIG1, CONFIGn);
		multiple_readback_mode = false;
	}
	CONFIGn = 0x00; // Reset CONFIGn
}
void BCI_LMSE_ESP::dataRateSettings(int _DR){
	CONFIGn = RREG(CONFIG1);
	switch(_DR){
		case 16:
			if(details) Serial.println("Data rate se to 16KSPS.");
			CONFIGn = (CONFIGn & DATA_RATE_OPS_MASK) | DATA_RATE_16K_MASK;
			break;
		case 8:
			if(details) Serial.println("Data Rate set to 8KSPS.");
			CONFIGn = (CONFIGn & DATA_RATE_OPS_MASK) | DATA_RATE_08K_MASK;
			break;
		case 4:
			if(details) Serial.println("Data Rate set to 4KSPS.");
			CONFIGn = (CONFIGn & DATA_RATE_OPS_MASK) | DATA_RATE_04K_MASK;
			break;
		case 2:
			if(details) Serial.println("Data Rate set to 2KSPS.");
			CONFIGn = (CONFIGn & DATA_RATE_OPS_MASK) | DATA_RATE_02K_MASK;
			break;
		case 1:
			if(details) Serial.println("Data Rate set to 1KSPS.");
			CONFIGn = (CONFIGn & DATA_RATE_OPS_MASK) | DATA_RATE_01K_MASK;
			break;
		case 500:
			if(details) Serial.println("Data Rate set to 500SPS.");
			CONFIGn = (CONFIGn & DATA_RATE_OPS_MASK) | DATA_RATE_500_MASK;
			break;
		case 250:
			if(details) Serial.println("Data Rate set to 250SPS.");
			CONFIGn = (CONFIGn & DATA_RATE_OPS_MASK) | DATA_RATE_250_MASK;
			break;
		default:
			if(details) Serial.println("No such Data Rate !");
			break;
	}
	WREG(CONFIG1, CONFIGn);
	CONFIGn = 0x00; // reset CONFIGn
}
void BCI_LMSE_ESP::testSignalSources(){
	CONFIGn = RREG(CONFIG2);
	if(internal_test_signals == true){
		bitSet(CONFIGn, 4);
		external_test_signals = false;
	}else{
		bitClear(CONFIGn, 4);
		external_test_signals = true;
	}
	WREG(CONFIG2, CONFIGn);
	CONFIGn = 0x00;
}
void BCI_LMSE_ESP::testSignalAmplitude(){
	CONFIGn = RREG(CONFIG2);
	if(double_calibration_signal == true){
		bitSet(CONFIGn, 2);
		simple_calibration_signal = false;
	}else{
		bitClear(CONFIGn, 2);
		simple_calibration_signal = true;
	}
	WREG(CONFIG2, CONFIGn);
	CONFIGn = 0x00;
}
void BCI_LMSE_ESP::testSignalFrequency(uint8_t _test_freq){
	CONFIGn = RREG(CONFIG2);
	switch(_test_freq){
		case 21:
			CONFIGn = (CONFIGn & TEST_SIGNAL_OPS_MASK) | TEST_SIGNAL_FREQ21_MASK;
			break;
		case 20:
			CONFIGn = (CONFIGn & TEST_SIGNAL_OPS_MASK) | TEST_SIGNAL_FREQ20_MASK;
			break;
		case 0:
			CONFIGn = (CONFIGn & TEST_SIGNAL_OPS_MASK) | TEST_SIGNAl_DC_FREQ0_MASK;
			break;
		default:
		Serial.println("No such calibration frequency !");
			break;
	}
	WREG(CONFIG2, CONFIGn);
	CONFIGn = 0x00; // reset CONFIGn buffer.
}

void BCI_LMSE_ESP::performTestSignal(uint8_t numCH, uint8_t gain_selection, boolean internal_source, boolean double_calibration_amplitude, uint8_t freqOfTest){
	//powerDownChannels(numCH);
	internal_test_signals = internal_source;
	CHnSET0 = RREG(CH1SET + numCH-1);
	CHnSET0 = (CHnSET0 & INPUT_SELECT_MASK) | INPUT_TEST_SIGNAL_MASK;
	switch(gain_selection){
		case PGA_GAIN1_SELECT:
			pga_gain_settings =(uint8_t) ( PGA_GAIN1_MASK << 4); break;
		case PGA_GAIN2_SELECT:
			pga_gain_settings =(uint8_t) ( PGA_GAIN2_MASK << 4); break;
		case PGA_GAIN4_SELECT:
			pga_gain_settings =(uint8_t) ( PGA_GAIN4_MASK << 4); break;
		case PGA_GAIN6_SELECT:
			pga_gain_settings =(uint8_t) ( PGA_GAIN6_MASK << 4); break;
		case PGA_GAIN8_SELECT:
			pga_gain_settings =(uint8_t) ( PGA_GAIN8_MASK << 4); break;
		case PGA_GAIN12_SELECT:
			pga_gain_settings =(uint8_t) ( PGA_GAIN12_MASK << 4); break;
		case PGA_GAIN24_SELECT:
			pga_gain_settings =(uint8_t) ( PGA_GAIN24_MASK << 4);break;
		default:
			Serial.println("WRONG PGA GAIN VALUE ..");
			pga_gain_settings =(uint8_t) ( PGA_GAIN1_MASK << 4); break;
			break;
	}
	CHnSET0 = (CHnSET0 & GAIN_SET_MASK) | (byte) pga_gain_settings;
	WREG(CH1SET + numCH-1, CHnSET0);
	channelSettings[numCH-1][CH_INPUT_SELECT] =(int) INPUT_TEST_SIGNAL_MASK;
	channelSettings[numCH-1][CH_GAIN] =(int) (pga_gain_settings >> 4);
	testSignalSources();
	double_calibration_signal = double_calibration_amplitude;
	testSignalAmplitude();
	testSignalFrequency(freqOfTest);
	//powerOnChannels(numCH, (uint8_t) INPUT_TEST_SIGNAL_MASK, gain_selection);
}

void BCI_LMSE_ESP::pdInternalReferenceBuffer(){
	CONFIGn = RREG(CONFIG3);
	if(internal_reference_buffer == true){
		bitSet(CONFIGn, 7);
	}else{
		bitClear(CONFIGn, 7);
	}
	WREG(CONFIG3,CONFIGn);
	CONFIGn = 0x00; // reset CONFIGn buffer.
}
void BCI_LMSE_ESP::biasSignalMeasurements(uint8_t numCH){
	CONFIGn = RREG(CONFIG3);
	CHnSET0 = RREG(CH1SET+numCH-1);
	BIAS_P  = RREG(BIAS_SENSP);
	BIAS_N  = RREG(BIAS_SENSN);
	if(signal_bias_in_meas == true){
		bitSet(CONFIGn, 4);
		if(internal_biasref_signal == true){
			bitSet(CONFIGn, 3); // this setting is used in conjonction with other bits.
		}else{
			bitClear(CONFIGn, 3);
		}
		CHnSET0 = (CHnSET0 & INPUT_SELECT_MASK)| INPUT_BIAS_MEAS_MASK;
		WREG(CH1SET+numCH-1, CHnSET0); // set the first 3bits of CHnSET for BIAS Measurements.
		CHnSET0 = 0x00; // reset CHnSET0 buffer.
		bitClear(BIAS_P, numCH-1);
		bitClear(BIAS_N, numCH-1);
		WREG(BIAS_SENSP, BIAS_P);
		WREG(BIAS_SENSN, BIAS_N);
		channelSettings[numCH-1][CH_INPUT_SELECT] = (int) INPUT_BIAS_MEAS_MASK;
		channelSettings[numCH-1][CH_BIAS_ROUTING] = 0;

	}else{
		bitClear(CONFIGn, 4);
	}
	WREG(CONFIG3, CONFIGn);
	CHnSET0 = 0x00; // reset CHnSET0 buffer.
	BIAS_N  = 0x00;  // reset BIAS_N buffer
	BIAS_P  = 0x00;  // reset BIAS_P buffer
	CONFIGn = 0x00; // reset CONFIGn buffer.
}
void BCI_LMSE_ESP::biasSignalReference(){
	CONFIGn = RREG(CONFIG3);
	if(internal_biasref_signal == true){
		bitSet(CONFIGn, 3); // used to generate an internal BIASREF signal = (AVDD + AVSS)/2.
	}else{
		bitClear(CONFIGn, 3); // BIASREF fed externally.
	}
	WREG(CONFIG3, CONFIGn);
	CONFIGn = 0x00; // reset CONFIG3 buffer.
}
void BCI_LMSE_ESP::biasBufferPower(){
	CONFIGn = RREG(CONFIG3);
	if(pd_BIAS_buffer == true){
		bitClear(CONFIGn, 2);
	}else{
		bitSet(CONFIGn, 2);
	}
	WREG(CONFIG3, CONFIGn);
	CONFIGn = 0x00;
}
void BCI_LMSE_ESP::biasSensFunction(){
	CONFIGn = RREG(CONFIG3);
	if(bias_loff_sens == false){
		bitClear(CONFIGn, 1);
	}else{
		bitSet(CONFIGn, 1);
	}
	WREG(CONFIG3, CONFIGn);
	CONFIGn = 0x00; 
}
void BCI_LMSE_ESP::biasLeadOffState(){
	CONFIGn = RREG(CONFIG3);
	if(bitRead(CONFIGn, 0) == 0){
		Serial.println("BIAS is Connected");
	}else{
		Serial.println("BIAS is not Connected !");
	}
	CONFIGn = 0x00;
}

// ******************    STOP STREAMING  *********************** //
void BCI_LMSE_ESP::stopADSStreaming(){
	isADSWorking =false;
	STOP(); // Stop continuous Conversion.
	delayMicroseconds(100);
	SDATAC(); // Stop read Data Continuous mode.
	resetStatusRegister();
	resetChannelsData();
}

void BCI_LMSE_ESP::startADSStreaming(){
	resetStatusRegister();
	resetChannelsData();
	CONFIGn = RREG(CONFIG4);
	bitClear(CONFIGn, 3); // set bit3 = 0 -> avoid to be in single shot mode.
	WREG(CONFIG4, CONFIGn);
	CONFIGn = 0x00; // reset the register.           
	RDATAC(); // Enter Read Data Continuous (Reading mode).
	START(); //  Begin the continuous conversion (Conversion Mode).
	isADSWorking = true;
}

int BCI_LMSE_ESP::isDataReady(){
	if(digitalRead(DRDY) ==0 && details == true){
		Serial.println("Data are ready !");
	}
	return(!(digitalRead(DRDY)));
}

// *****************************  REGISTER READ and WRITE COMMANDS ********************************* //
// These Commands are: RREG, WREG.

// ******************************  DEVICE ID  ********************************************************//
byte BCI_LMSE_ESP::ADS1299ID() {
		byte data = RREG(ID);
	return data;
}

void BCI_LMSE_ESP::ADS1299ID2() {
	digitalWrite(CS, LOW);
	SPI_transfer(_SDATAC);
	SPI_transfer(_BYTE1_RREG);
	SPI_transfer(_pop_read);
	byte data = SPI_transfer(_pop_read);
	SPI_transfer(_RDATAC);
	digitalWrite(CS, HIGH);
	Serial.print("Device ID: ");
	Serial.print("0x00, ");
	Serial.print("0x");
	Serial.print(data, HEX);
	Serial.print(", ");
	for(uint8_t i=0; i<8; i++){
		Serial.print(bitRead(data, 7-i));
		if(i!=7) Serial.print(", ");
	}
	Serial.print("\n");
	Serial.println("-------------------------------------------------");
}


// ********************** RREG FUNCTION for Single REGISTER ******************************************// 
byte BCI_LMSE_ESP::RREG(byte _regAdd) {
	
	mirrorInitialize();
	byte _second_command = 0x00;
	byte _first_command = _BYTE1_RREG | _regAdd; // has format (00100000 + 000rrrrr)
	SDATAC();	
	digitalWrite(CS, LOW); 	
				// enable communication, CS must be low during all RREG command.
	//SPI_transfer(_SDATAC); 					// because in RDATAC mode the RREG will be ignored.
	delay(_tSDECODE +0.008);
	SPI_transfer(_first_command); 			// command to point to first register address to begin from.
	delay(_tSDECODE +0.008); 				// Command byte decode Time
	SPI_transfer(_second_command);			// 2nd Command = 0x00, in the case of single register.
	delay(_tSDECODE +0.008);
	mirror[_regAdd] = SPI_transfer(_pop_read); // only One register to read => _pop_read = 1-1= 0. 
	delay(_tSDECODE +0.008);
	digitalWrite(CS, HIGH); 					// end of SPI communication while mirror contain data transfered from register which address is = _regAdd
	if(details) {
	registerNameDisplay(_regAdd);
	DecToHex(_regAdd);
		Serial.print(", ");
		DecToHex(mirror[_regAdd]);
		Serial.print(", ");
		for(byte j = 0; j<8; j++){

			Serial.print(bitRead(mirror[_regAdd], 7-j), BIN);
			if(j!=7) Serial.print(", ");
		}
		Serial.println("");
		Serial.println("-------------------------------------------------");

	}
	RDATAC();
	return mirror[_regAdd];			// return requested register value
}

// ********************** RREG FUNCTION for Multiple REGISTERS ******************************************// 
void BCI_LMSE_ESP::RREGS(byte _regAdd, int _second_command) {
	mirrorInitialize();
    byte _first_command = _BYTE1_RREG | _regAdd;    //  RREG expects 001rrrrr where rrrrr = _address
    
    SDATAC(); // because in RDATAC mode the RREG will be ignored.
    digitalWrite(CS, LOW); 							//  open SPI communication
    					
    delay(_tSDECODE +0.008);					// Command byte decode Time, datasheet page. 43.
    SPI_transfer(_first_command); 					// Command and register address.		   			
    SPI_transfer(_second_command);					// specifies the number of registers to read -1.
    
        for(int i = 0; i <= _second_command ;i++) {
        	  mirror[_regAdd + i] = SPI_transfer(_pop_read); 	//  add register byte to mirror array
       
        }
	digitalWrite(CS, HIGH); 					//  close SPI

	if(details){	            				//  more detailed diplay
		for(int i = 0; i<= _second_command; i++){
			registerNameDisplay(_regAdd + i);
			DecToHex(_regAdd + i);
			Serial.print(", ");
			DecToHex(mirror[_regAdd + i]);
			Serial.print(", ");
			for(int j = 0; j<8; j++){
				Serial.print(bitRead(mirror[_regAdd + i], 7-j), BIN);
				if(j!=7) Serial.print(", ");
			}
			Serial.print("\n");
			
		}
		Serial.println("-------------------------------------------------");
    }
    RDATAC();
}

// ********************** WREG FUNCTION for Single Register ******************************************// 
void BCI_LMSE_ESP::WREG(byte _regAdd, byte _value) {	//  One register to write at (_regAdd) address.
    byte _first_command = _BYTE1_WREG | _regAdd; 		//  WREG expects 010rrrrr where rrrrr = _regAdd
    byte _second_command = 0x00;
    digitalWrite(CS, LOW); 								//  SPI communication enabled.
    SPI_transfer(_first_command);						//  Send WREG command & address
    delay(_tSDECODE +0.008); 							// Command byte decode Time
    SPI_transfer(_second_command);						//	Send number of registers to read -1
    SPI_transfer(_value);								//  Write the value to the register
    digitalWrite(CS, HIGH); 							//  SPI communication closed.1
	mirror[_regAdd] = _value;							//  update the mirror array
	if(details){ 										//  more detailed display
		Serial.print(F("Register "));
		registerNameDisplay(_regAdd);
		DecToHex(_regAdd);
		Serial.println(F(" is correctly set."));
		Serial.println("-------------------------------------------------");
		Serial.println("-------------------------------------------------");
	}
}

// ********************** WREG FUNCTION for Multiple REGISTERS ******************************************// 

void BCI_LMSE_ESP::WREGS(byte _regAdd, byte _second_command){
	byte _first_command = _BYTE1_WREG | _regAdd; 			// WREG expects 0x010rrrrr, where rrrrr = _regAdd
	digitalWrite(CS, LOW);									// enable SPI Communication.
	SPI_transfer(_first_command);							// Send the first Byte (Command + Starting Register Address).
	delay(_tSDECODE +0.008); 								// Command byte decode Time
	SPI_transfer(_second_command);							// Send the number of registers to write - 1.
	uint8_t i = 0;
	do {
		SPI_transfer(mirror[i]); 							// Write to registers from data saved in mirror.
		i++;
	} while(i<=(_regAdd + _second_command));
	digitalWrite(CS, HIGH); 								// end of the SPI communication.
	if (details) {
		Serial.println("-------------------------------------------------");
		Serial.print(F("Registers "));
		registerNameDisplay(_regAdd);
		DecToHex(_regAdd);
		Serial.print(F(" To "));
		registerNameDisplay(_regAdd + _second_command);
		DecToHex(_regAdd + _second_command);
		Serial.println(F(" are correctly set."));
		Serial.println("-------------------------------------------------");
	}

	}

	/* -----------------------------------------------------*/

//******************* String-Byte Converters ***********************************//
void BCI_LMSE_ESP::registerNameDisplay(byte _regAdd) {
	switch(_regAdd){
		case ID:
			Serial.print("Device ID: ");
			break;
		case CONFIG1:
			Serial.print("CONFIG1: ");
			break;
		case CONFIG2:
			Serial.print("CONFIG2: ");
			break;
		case CONFIG3:
			Serial.print("CONFIG3: ");
			break;
		case LOFF:
			Serial.print("LOFF: ");
			break;
		case CH1SET:
			Serial.print("CH1SET: ");
			break;
		case CH2SET:
			Serial.print("CH2SET: ");
			break;
		case CH3SET:
			Serial.print("CH3SET: ");
			break;
		case CH4SET:
			Serial.print("CH4SET: ");
			break;
		case CH5SET:
			Serial.print("CH5SET: ");
			break;
		case CH6SET:
			Serial.print("CH6SET: ");
			break;
		case CH7SET:
			Serial.print("CH7SET: ");
			break;
		case CH8SET:
			Serial.print("CH8SET: ");
			break;
		case BIAS_SENSP:
			Serial.print("BIAS_SENSP: ");
			break;
		case BIAS_SENSN:
			Serial.print("BIAS_SENSN: ");
			break;
		case LOFF_SENSP:
			Serial.print("LOFF_SENSP: ");
			break;
		case LOFF_SENSN:
			Serial.print("LOFF_SENSN: ");
			break;
		case LOFF_FLIP:
			Serial.print("LOFF_FLIP: ");
			break;
		case LOFF_STATP:
			Serial.print("LOFF_STATP: ");
			break;
		case LOFF_STATN:
			Serial.print("LOFF_STATN: ");
			break;
		case GPIO_ADS:
			Serial.print("GPIO_ADS: ");
			break;
		case MISC1:
			Serial.print("MISC1: ");
			break;
		case MISC2:
			Serial.print("MISC2: ");
			break;
		case CONFIG4:
			Serial.print("CONFIG4: ");
			break;
		default:
			break;
	}
}

/// ************************************* ADS MANAGER ****************************///

// 1° ***  Deactivate/Activate Channels *** /
void BCI_LMSE_ESP::powerDownChannels(uint8_t numCH){ // numCH is the channel number.

	
	//byte start_CH = 1;    // strating channels number. 
	//byte end_CH = 8;     // end channels number.
	SDATAC();             // to stop the default RDATAC mode.
	delay(1);
	CHnSET0 = RREG(CH1SET + numCH-1); 	// is to read the current channel setting.
	CHnSET0 |= INPUT_SHORTED_MASK; 		// When powering down a channel TI recommends that the channel
									    // be set ti input short mode by setting the appropriate MUXn[2:0]
										// to 001 of the CHnSET register --> we used here 
										// INPUT_SHORTED_MASK  
	channelSettings[numCH-1][CH_PWR_MODE] = 1; 		// set the channelSettings array at channel power-down level.
	channelSettings[numCH-1][CH_GAIN] = 0;			// set the channelSettings array at channel PGA gain level.
	channelSettings[numCH-1][CH_SRB2] = 0; 			// set the channelSettings array at channel SRB2 level
	channelSettings[numCH-1][CH_INPUT_SELECT] = 1;  // set the channelSettings array at channel input selection level.
	channelSettings[numCH-1][CH_BIAS_ROUTING] = 0;  // set the channelSettings array at channel BIAS SENS (postive & negative) routing level.
	channelSettings[numCH-1][CH_SRB1] = 0;          // set the channelSettings array at channel SRB1 level.
	// ********************This parts of code must be checked ****************************
	/*BIAS_SENS_routing[numCH-1] = false;
	SRB1_include = false;
	SRB2_include[numCH-1] = false;*/

	//******************************************************************* 
	CHnSET0 &= ~(SRB2_CH_MASK);  // to open the SRB2 connection. (bitClear(CHnSET0, 3); it does the same thing).
	CHnSET0 |= INPUT_OFF_MASK;  // power-Down the channal numCH.(bitSet(CHnSET0, 7 -> it does the same thing.)
	uint8_t i = 4;
	do {    
		bitClear(CHnSET0, i);  // to reduce automatically the PGA gain.
		i++;
	} while(i<= 6);
	i = 0;
	WREG(CH1SET + numCH-1, CHnSET0); // write the new value to CHnSET register(s).
	//Next its necessary to disconnect any channels from BIAS voltage drivation NEGATIVE and POSITIVE.
	BIAS_P = RREG(BIAS_SENSP); 		// Read BIAS Positive Signal derivation Register 
	bitClear(BIAS_P, numCH-1);   	// disable the routing of numCH-th into positive BIAS derivation.
	WREG(BIAS_SENSP, BIAS_P);    	// Write the new value to BIAS_SENSP register.
	BIAS_N = RREG(BIAS_SENSN);   	// Read BIAS Negative Signal derivation Register.
	bitClear(BIAS_N, numCH-1);   	// disable the routing of numCH-th into negative BIAS derivation.
	WREG(BIAS_SENSN, BIAS_N);   	// Write the new value to BIAS_SENSN register.
	leadOffSettings[numCH][0] = leadOffSettings[numCH][1] = 0x00; // control ON/OFF impedance measurement.
	BIAS_P = 0x00; // reset the BIAS_P buffer.
	BIAS_N = 0x00; // reset the BIAS_N buffer.
	CHnSET0 = 0x00; // reset the CHnSET0 buffer.
	if(details){
		Serial.println("----------------------------------------------------");
	}
	
}

void BCI_LMSE_ESP::powerOnChannels(uint8_t numCH, uint8_t input_selection, uint8_t gain_selection){

	//byte start_CH = 1;    // strating channels number. 
	//byte end_CH = 8;     // end channels number.
	SDATAC();
	defaultChannelSettings(numCH);
	switch(gain_selection){
		case PGA_GAIN1_SELECT:
			pga_gain_settings =(uint8_t) PGA_GAIN1_MASK; break;
		case PGA_GAIN2_SELECT:
			pga_gain_settings =(uint8_t) PGA_GAIN2_MASK; break;
		case PGA_GAIN4_SELECT:
			pga_gain_settings =(uint8_t) PGA_GAIN4_MASK; break;
		case PGA_GAIN6_SELECT:
			pga_gain_settings =(uint8_t) PGA_GAIN6_MASK; break;
		case PGA_GAIN8_SELECT:
			pga_gain_settings =(uint8_t) PGA_GAIN8_MASK; break;
		case PGA_GAIN12_SELECT:
			pga_gain_settings =(uint8_t) PGA_GAIN12_MASK; break;
		case PGA_GAIN24_SELECT:
			pga_gain_settings =(uint8_t) PGA_GAIN24_MASK;break;
		default:
			Serial.println("WRONG PGA GAIN VALUE ..");
			pga_gain_settings =(uint8_t) PGA_GAIN1_MASK; break;
			break;
	}
	channelSettings[numCH-1][CH_INPUT_SELECT] =(int) input_selection;
	channelSettings[numCH-1][CH_GAIN] =(int) pga_gain_settings;
	CHnSET0 |=(channelSettings[numCH-1][CH_PWR_MODE]<<7); // to get Channel in power Mode ON (the bit 7).

	CHnSET0 |=(channelSettings[numCH-1][CH_GAIN]<<4); // to get gain from channelsettings array and put it in [4:6] bits.
	
	if(SRB2_include[numCH-1] == false) {
		channelSettings[numCH-1][CH_SRB2] = 0;
	}else{
		channelSettings[numCH-1][CH_SRB2] = 1;
	}
	CHnSET0 |=(channelSettings[numCH-1][CH_SRB2]<<3); // to get the state of the SRB2 connection and put it in
	CHnSET0 |=channelSettings[numCH-1][CH_INPUT_SELECT];
	WREG(CH1SET + numCH-1, CHnSET0);
	CHnSET0 = 0x00; // reset CHnSET0 buffer. 

	// See datasheet page.59 for how to configure MISC1 register.
	if(SRB1_include == false) {   // the case where SRB1 is not included.
		channelSettings[numCH-1][CH_SRB1] = 0;
		MISC1_buff = RREG(MISC1); // Read the content of MISC1 into the buffer MISC1_buff.
		bitClear(MISC1_buff, 5); // Switch SRB1 is opened.
		WREG(MISC1, MISC1_buff); // write the new value of MISC1_buff to MISC1 register
		
	}else{					// the case where SRB1 will be connected to all 8 channels inverting inputs.
		channelSettings[numCH-1][CH_SRB1] = 1;
		MISC1_buff = RREG(MISC1); // Read the content of MISC1 into the buffer MISC1_buff.
		bitSet(MISC1_buff, 5); // Switch SRB1 is closed.
		WREG(MISC1, MISC1_buff); // write the new value of MISC1_buff to MISC1 register
	} 
  
	if(BIAS_SENS_routing[numCH-1] == false) {  		// Route Channel 'numCH' into BIAS AMP is disabled. 
		channelSettings[numCH-1][CH_BIAS_ROUTING] = 0;
		BIAS_P = RREG(BIAS_SENSP);
		BIAS_N = RREG(BIAS_SENSN);
		bitClear(BIAS_P, numCH-1);
		bitClear(BIAS_N, numCH-1);
		WREG(BIAS_SENSP, BIAS_P);
		WREG(BIAS_SENSN, BIAS_N);
	
	}else{  									// Route Channel 'numCH' into BIAS AMP is enabled. 
		channelSettings[numCH-1][CH_BIAS_ROUTING] = 1;
		BIAS_P = RREG(BIAS_SENSP);
		BIAS_N = RREG(BIAS_SENSN);
		bitSet(BIAS_P, numCH-1);
		bitSet(BIAS_N, numCH-1);
		WREG(BIAS_SENSP, BIAS_P);
		WREG(BIAS_SENSN, BIAS_N);
	}
		MISC1_buff = 0x00; // reset the MISC1_buff.
		BIAS_P = 0x00; // reset the CHnSET0 buffer.
		BIAS_N = 0x00; // reset the CHnSET1 buffer.
		pga_gain_settings = 0; // reset gain selection.
		RDATAC();
}
void BCI_LMSE_ESP::zeroChannelSettings() {

	for(uint8_t i=0; i<8; i++) {
		for(uint8_t j =0; j<=5; j++){
			channelSettings[i][j] = 0;
		}
	}
}

void BCI_LMSE_ESP::defaultChannelSettings(uint8_t numbCH){
	channelSettings[numbCH-1][CH_PWR_MODE] = 0;
	channelSettings[numbCH-1][CH_GAIN] = 6;
	channelSettings[numbCH-1][CH_SRB2] = 0;
	channelSettings[numbCH-1][CH_INPUT_SELECT] = 0;
	channelSettings[numbCH-1][CH_BIAS_ROUTING] = 0;
	channelSettings[numbCH-1][CH_SRB1] = 0;
}
void BCI_LMSE_ESP::resetStatusRegister(){
	for(byte i = 0; i<3; i++){
		status_reg[i] = 0x00; 
	}

}
void BCI_LMSE_ESP::resetChannelsData(){
	for(int i=0; i<8; i++){
		channel[i] = 0;
	}
}
void BCI_LMSE_ESP::mirrorInitialize(){
	for(byte i = 0x00; i<0x17; i++){
		mirror[i] = 0x00;
	}
}

/* ------------------------------------------------------*/
////////////////////**** Transfer Function *******************////////
byte  BCI_LMSE_ESP::SPI_transfer(byte _data) {
	byte ESP_byte = 0x00;
	
	ESP_byte = vspi-> transfer(_data);
   //SPI.endTransaction();
	 return ESP_byte;
}

//*********** printing HEX values ***************//
void BCI_LMSE_ESP::DecToHex(byte _regData){
	Serial.print("0x");
	if(_regData <0x10) {
		Serial.print("0");}
	Serial.print(_regData, HEX);
}


///////////// end ///////////////////

