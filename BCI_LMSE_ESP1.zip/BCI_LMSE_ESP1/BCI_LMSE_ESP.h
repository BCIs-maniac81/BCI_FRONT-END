// BCI_LMSE_ESP.h 

# ifndef ____BCI_LMSE_ESP__
# define ____BCI_LMSE_ESP__

# include <Definitions_ESP.h>
# include <stdio.h>
# include <stdint.h>
# include <Arduino.h>



//**** breakout ESP32 ****//
/* DRDY = 12, RESET = 13, CS = 15, MOSI = 23, MISO = 19, SCK = 18 */

class BCI_LMSE_ESP {
public:

    
    int DRDY, CS, RST;      //pin numbers for "Data Ready" (DRDY), "Chip Select" CS (Datasheet, pg. 26) and /Reset.
                  // Clock define
    int DIV_01, DIV_02; //
    byte status_reg[3];
    byte mirror[24];        // array used to mirror register Data. (24 * 8), while ADS1299 has 24 internam registers.
    BOOL details;           // set true if need to show some details in the terminal, if not set to false. 
    int number_CH = 8;      //assume 8 channel (without Daisy chain)

    byte bufferByte=0x00;
    long int channel[8];        // array to record 8 channels streaming values at each moment.
    byte _pop_read =0x00;   // pop operation to read output buffered data.
    
    byte CHnSET0 = 0x00;    // First Buffer used to read internal CHnSET registers values.
    byte BIAS_P = 0x00;     // buffer for postive BIAS_SENS.
    byte BIAS_N = 0x00;     // buffer for Negative BIAS_SENS
    byte MISC1_buff = 0x00; // buffer for MISC1 register.
    byte CONFIGn = 0x00;    // buffer for CONFIG1, CONFIG2, CONFIG3 and CONFIG4.

    char leadOffSettings[8][2];;
    int channelSettings[8][6];  // array to hold current channel settings
    uint8_t pga_gain_settings = 0; // used inside powerOnChannels method to set a MASK into CHnSET settings.

    //**** write Data To serial port --> binary format

    long int buff_val1; // 1st buffer 
    byte* (buff_val2) = (byte*) (&buff_val1);
    //boolean usingsimulatedData = false;

    //**** write Data To serial port --> ModularEEG format.
    byte sync0;
    byte sync1;
    byte version;
    byte foo;

    long buff_val32;
    int buff_val_i16;
    unsigned int buff_val1_u16;
    byte*  buff_val2_u16 = (byte *)(&buff_val1_u16);

    byte switches;

   
    boolean BIAS_SENS_routing[8];      // Register Setter for channelSettings array.
    boolean SRB1_include = false;      // setter value for channelSettings array.
    boolean SRB2_include[8];           // Register Setter for channelSetting array.
    boolean daisy_chain_mode = false; 		    // daisy_chain mode if true.
    boolean multiple_readback_mode = true;      //	Multiple readback mode if daisy_chain mode is false.
    boolean internal_test_signals = true;       // test signals are generated internally.
    boolean external_test_signals = false; 		// test signals are driven externally.
    boolean double_calibration_signal = false;  // calibration signal Amplitude = 2*-(VREFP - VREFN)/2400.
    boolean simple_calibration_signal = true;   // calibration signal Amplitude = 1*-(VREFP - VREFN)/2400.
    boolean internal_reference_buffer = true; 	// to enable the internal reference buffer.
    boolean signal_bias_in_meas = false;		// used to measure BIAS signal if true.
    boolean internal_biasref_signal = true; // BIASREF signal is generated internally = (AVDD + AVSS / 2).
    boolean pd_BIAS_buffer = false; 		// BIAS buffer power down if true or enabled if false.
    boolean bias_loff_sens = false;		// BIAS sens function is disabled if false or enabled if true.
    boolean isADSWorking;
    boolean positive_input_is_ref = true;

     // ******   PROTOTYPES **********

    //***************** Initialization Sequences ************************** //
    void initialize(int _ESP_DRDY, int _ESP_CS, int _ESP_RST); // ESP_SPI settings;
    void resetADS1299();
    void daisyChainModeTest();		// to determine if device in Daisy-Chain mode or in multiple readBack mode.
    void dataRateSettings(int _DR); // to set the Data Rate. --> DR[2:0] CONFIG1. 
    void testSignalSources(); 		// to set the test signals source --> bit4 CONFIG2.
    void testSignalAmplitude();		// to set the test signals amplitude --> bit2 CONFIG2.
    void testSignalFrequency(uint8_t _test_freq); // to determine the calibration signal frequency.
    void performTestSignal(uint8_t numCH, uint8_t gain_selection, boolean internal_source, boolean double_calibration_amplitude, uint8_t freqOfTest); 
                                            // This function is used to perform any signal test.
    void pdInternalReferenceBuffer(); // to control the internal reference buffer -->bit7 CONFIG3 
    void biasSignalMeasurements(uint8_t numCH); // to enable BIAS measurements with any channel.
    void biasSignalReference(); // to set the BIASREF signal source (internally or externally).
    void biasBufferPower(); 	// to determine the BIAS buffer power state.
    void biasSensFunction();	// to enable the BIAS sens function. 
    void biasLeadOffState();		// to read-only the BIAS status (connected or not). 
    void mirrorInitialize(); 	// RESET MIRROR

    // ************* SETTERS ******************** //
    void SRB2SETTER(uint8_t numCH); // to enable SRB2 on one channel or more.
    void SRB1SETTER();  // to enable SRB1 to all channels.
    void BIAS_SENS_ROUTING(uint8_t numCH);

    // ************* System Commands functions ********************** // // **** for more information see Datasheet page.40
    void WAKEUP();      // function to Wake-up from Standby low energy Mode.
    void STANDBY();     // Standby mode function.
    void RESET();       // Reset the Device function.
    void START();       // Start or Restart (synchronize) Conversion Function.
    void STOP();        // Stop conversion function.

    // ************* Data Read Commands  *************************** //
    void RDATAC();      // Read Data Continuous Mode Function.
    void SDATAC();      // Stop Read Data Continuously Function.
    void RDATA();       // Read Data by Command Function.
    void RDATA2();      // Send _RDATA command to enter in RDATA mode
    
    void startADSStreaming();// strat streaming data
    void stopADSStreaming(); // Stop streaming Data
    int isDataReady();      // to test if Data are ready (DRDY\).
    void updateChannels();   // 
    void allDataChannelsDisplay(long signal_samples);
    void BinaryDataSenderToSerial(uint8_t bci_dimension,long signal_samples);
    void dataSenderToSerialAsOpenEEG_brainBay(long signal_samples);

    // ************ Register Read Commands ***************************//
    byte ADS1299ID();
    void ADS1299ID2();
    byte RREG(byte _regAdd);
    void RREGS(byte _regAdd, int _second_command); // To read Multiple Consecutive Registers (DATASHEET page-43)
    void registerNameDisplay(byte _regAdd);
    void WREG(byte _regAdd, byte _value); //
    void WREGS(byte _regAdd, byte _second_command); //
    void DecToHex(byte _regData); // function that allow to view returned data in Hexadecimal format.
    
    //************************* Data Channel Control ************************* ///
    void zeroChannelSettings();
    void powerDownChannels(byte numCH);
    void powerOnChannels(uint8_t numCH, uint8_t input_selection, uint8_t gain_selection);
    void defaultChannelSettings(uint8_t numbCH);
    void resetStatusRegister();
    void resetChannelsData();


    ///************************** SPI transfer command *********************************//
    
    //SPI Arduino Library Stuff
    byte SPI_transfer(byte _data);

    //------------------------//
    // void attachInterrupt();
    // void detachInterrupt(); // Default
    // void begin(); // Default
    // void end();
    // void setBitOrder(uint8_t);
    // void setDataMode(uint8_t);
    // void setClockDivider(uint8_t);
    //------------------------//
    
    
    
    };

# endif
